//
//  SingupViewController.swift
//  NIBMCafe
//
//  Created by Admin on 2021-04-11.
//

import UIKit
import Firebase

class SingupViewController: UIViewController {

    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtphoneNumber: UITextField!
    @IBOutlet weak var txtpassword: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func onRegisterbtn(_ sender: Any) {
        
        if validateInput(){
            authenticateUser(email: txtemail.text!, password: txtpassword.text!)
            
        }else{
            print("Input Error Found")
        }
    }
    
    @IBAction func onLoginbtn(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    func authenticateUser(email:String,password:String){
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let err = error{
                print(err.localizedDescription)
                return
            }
            
            let sessionManger = SessionManager()
            sessionManger.saveUserLoging()
        }
    }
    
    
    
    func validateInput()-> Bool{
        guard let name = txtname.text else {
            print("name is null")
            return false
        }
        
        guard let email = txtemail.text else {
            print("email is null")
            return false
        }
        
        guard let phoneNumber = txtphoneNumber.text else {
            print("phone is null")
            return false
        }
        
        guard let password = txtpassword.text else {
            print("name is null")
            return false
        }
        
        if name.count < 5{
            print("Enter a valied Name")
            return false
        }
        
        if email.count < 5{
            print("Enter a valied email")
            return false
        }
        
        if phoneNumber.count < 10{
            print("Enter a valied phoneNumber")
            return false
        }
        
        if password.count < 5{
            print("Enter a valied Name")
            return false
        }
        
        return true
        
    }
    
    
   
}


